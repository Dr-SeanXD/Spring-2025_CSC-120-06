#include <iostream>
using namespace std;

/**
 * Add two numbers together and return the result.
 * 
 * @param num1 The first number for addition.
 * @param num2 The second number for addition.
 * @return The result of the addition.
 */
int add(int num1, int num2) {
    int result = num1 + num2;
    return result;
}

/**
 * Substract two numbers and return the result.
 * 
 * @param num1 The first number for substraction.
 * @param num2 The second number for substraction.
 * @return The result of the subtraction.
 */
int substract(int num1, int num2) {
    int result = num1 - num2;
    return result;
}

/**
 * Mutiply two numbers and return the result.
 * 
 * @param num1 The first number for multiplication.
 * @param num2 The second number for multiplication.
 * @return The result of the multiplication.
 */
int multiply(int num1, int num2) {
    int result = num1 * num2;
    return result;
}

/**
 * Divide two numbers and return the result.
 * 
 * @param num1 The first number for division.
 * @param num2 The second number for division.
 * @return The result of the division.
 */
double divide(double num1, double num2) {
    double result = num1 / num2;
    return result;
}

/**
 * Input a number and return it.
 * 
 * @return The number that was obtained via console.
 */
int askNumber() {
    int num;
    cin >> num;
    return num;
}

/**
 * Show (print) the menu for the mathematic operations.
 */
void showMenu() {
    cout << "1. Add\n";
    cout << "2. Substract\n";
    cout << "3. Multiply\n";
    cout << "4. Divide\n";
    cout << "5. Exit\n";
}

/**
 * Call the showMenu() function and asks the user to input a choice.
 * 
 * @return The choice the user entered via the console.
 */
int askOperator() {
    showMenu();
    int choice;
    cout << "Choose 1 of the above options: ";
    cin >> choice;
    return choice;
}

/**
 * Using the numbers and choice (operator) provided, perform the specified mathematic operation.
 * 
 * @param num1 The first number in the operation.
 * @param num2 The second number in the operation.
 * @param choice The operation the function will do.
 */
void calculate(int num1, int num2, int choice) {
    switch (choice) {
        case 1:
            cout << "Result: " << add(num1, num2) << '\n';
            break;
        case 2:
            cout << "Result: " << substract(num1, num2) << '\n';
            break;
        case 3:
            cout << "Result: " << multiply(num1, num2) << '\n';
            break;
        case 4:
            if (num2 == 0) {
                cout << "Divisor cannot be 0!\n";
            }
            else {
                cout << "Result: " << divide(double(num1), double(num2)) << '\n';
            }
            break;
        default:
            cout << "Invalid Input!\n";
    }
    cout << '\n';
}