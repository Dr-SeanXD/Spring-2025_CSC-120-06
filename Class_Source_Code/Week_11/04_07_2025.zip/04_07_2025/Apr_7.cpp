/*
 * @Author       : Sean Lin
 * @Date Created : Apr. 7th, 2025
 * @File Name    : Apr_7.cpp
 * @Description  : Demonstrates the syntax and usages of functions.
 */

#include <iostream>

//Include the file "calculator.cpp" to access the functions.
#include "calculator.h"

using namespace std;

int main() {

    //Declare the variables for the mathematic operation(s).
    int num1, num2, choice;

    //Ask the first number via the askNumber() function.
    cout << "First Number: ";
    num1 = askNumber();

    //Ask the second number via the askNumber() function.
    cout << "Second Number: ";
    num2 = askNumber();

    choice = askOperator();

    //Call the calculate() function to perform mathematic operations specified by the user.
    calculate(num1, num2, choice);

    return 0;
}