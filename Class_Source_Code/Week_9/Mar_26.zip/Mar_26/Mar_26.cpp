/*
 * @Author       : Sean Lin
 * @Date Created : Mar. 26th, 2025
 * @File Name    : Mar_26.cpp
 * @Description  : Demonstrate how to read and write from a file.
 */

#include <iostream>
#include <fstream>
using namespace std;

int main() {
    
    //Try to open the file.
    fstream inFile;
    inFile.open("inventory.txt");

    //See if the file exists.
    if (!inFile) {
        cout << "File doesn't exist!\n";
    }
    else {
        cout << "File opened successfully!\n";

        //Declare a string.
        string line;

        getline(inFile, line);

        //REMEMBER to close the file at the end!
        inFile.close();

        ofstream outFile;
        outFile.open("output.txt");

        outFile << line;

        outFile.close();
    }


    return 0;
}